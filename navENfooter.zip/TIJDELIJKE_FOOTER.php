<footer>
    <div class="footer-top col-lg-6">
        <h3>Contact</h3>
        <a href="mailto:example@gmail.com">example@gmail.com</a>
        <a href="Tel:0651036882">06-51036882</a>
    </div>
    <div class="footer-bottom col-lg-6">
        <h3>Links</h3>
    </div>  
</footer>